// popup.js — Lógica do popup da extensão KainowRadar Shopee
;(function () {
  'use strict'

  const SHOPEE_OFFERS_URL = 'https://affiliate.shopee.com.br/offer/product_offer'

  // ─── Elementos ──────────────────────────────────────────────────────
  const $ = id => document.getElementById(id)
  const statusDot      = $('status-dot')
  const statusText     = $('status-text')
  const shopeeStatus   = $('shopee-status')
  const btnOpenShopee  = $('btn-open-shopee')
  const inputStoreId   = $('input-store-id')
  const inputMaxLinks  = $('input-max-links')
  const savedBanner    = $('saved-banner')
  const progressSect   = $('progress-section')
  const logArea        = $('log-area')
  const popupBar       = $('popup-bar')
  const statFound      = $('stat-found')
  const statImported   = $('stat-imported')
  const statPages      = $('stat-pages')
  const btnSave        = $('btn-save')
  const btnStart       = $('btn-start')
  const btnRowMain     = $('btn-row-main')
  const btnRowRunning  = $('btn-row-running')
  const btnGoto        = $('btn-goto')
  const btnStop        = $('btn-stop')

  // ─── Estado ─────────────────────────────────────────────────────────
  let isRunning = false
  let scrapeTab = null  // tabId da aba da Shopee com scraping

  // ─── Logs ────────────────────────────────────────────────────────────
  function log(msg, type = '') {
    logArea.classList.add('active')
    const line = document.createElement('div')
    line.className = 'log-line ' + type
    line.textContent = new Date().toLocaleTimeString('pt-BR', { hour:'2-digit', minute:'2-digit', second:'2-digit' }) + ' ' + msg
    logArea.appendChild(line)
    logArea.scrollTop = logArea.scrollHeight
    // Limita 50 linhas
    while (logArea.children.length > 50) logArea.removeChild(logArea.firstChild)
  }

  // ─── UI helpers ───────────────────────────────────────────────────────
  function setStatus(msg, dotClass = 'yellow') {
    statusText.textContent = msg
    statusDot.className = 'status-dot ' + dotClass
  }

  function setShopeeStatus(logged) {
    shopeeStatus.textContent = logged ? '✅ Logado' : '❌ Não logado'
    shopeeStatus.className = 'badge-status ' + (logged ? 'ok' : 'fail')
    btnOpenShopee.style.display = logged ? 'none' : 'block'
  }

  function setProgress(found, imported, pages, pct) {
    statFound.textContent    = found.toLocaleString('pt-BR')
    statImported.textContent = imported.toLocaleString('pt-BR')
    statPages.textContent    = pages
    popupBar.style.width     = Math.min(100, pct || 0) + '%'
    progressSect.classList.add('active')
  }

  function setRunning(running) {
    isRunning = running
    btnRowMain.style.display    = running ? 'none' : 'flex'
    btnRowRunning.style.display = running ? 'flex' : 'none'
    if (!running) {
      setStatus('Pronto', 'green')
    }
  }

  function showSavedBanner() {
    savedBanner.classList.add('show')
    setTimeout(() => savedBanner.classList.remove('show'), 2500)
  }

  // ─── Carregar config ─────────────────────────────────────────────────
  function loadConfig() {
    chrome.storage.local.get(['kainow_store_id', 'kainow_max_links'], data => {
      if (data.kainow_store_id) inputStoreId.value = data.kainow_store_id
      if (data.kainow_max_links) inputMaxLinks.value = data.kainow_max_links
      validateForm()
    })
  }

  // ─── Salvar config ───────────────────────────────────────────────────
  function saveConfig() {
    const storeId  = parseInt(inputStoreId.value.trim())
    const maxLinks = parseInt(inputMaxLinks.value.trim()) || 1000000

    if (!storeId || storeId < 1) {
      setStatus('⚠️ Informe um Store ID válido', 'yellow')
      inputStoreId.focus()
      return
    }

    chrome.storage.local.set({
      kainow_store_id:  storeId,
      kainow_max_links: maxLinks
    }, () => {
      showSavedBanner()
      log(`Config salva: Store #${storeId}, max ${maxLinks.toLocaleString('pt-BR')} links`, 'ok')
      validateForm()
    })
  }

  // ─── Validação básica ─────────────────────────────────────────────────
  function validateForm() {
    const storeId = inputStoreId.value.trim()
    btnStart.disabled = !storeId || storeId < 1 || isRunning
  }

  inputStoreId.addEventListener('input', validateForm)
  inputMaxLinks.addEventListener('input', validateForm)

  // ─── Verifica login na Shopee ─────────────────────────────────────────
  async function checkShopeeLogin() {
    try {
      // Tenta encontrar uma aba aberta do Shopee Afiliados
      const tabs = await chrome.tabs.query({ url: 'https://affiliate.shopee.com.br/*' })
      if (!tabs.length) {
        setShopeeStatus(false)
        return false
      }

      // Pinga o content script
      return new Promise(resolve => {
        chrome.tabs.sendMessage(tabs[0].id, { type: 'PING' }, res => {
          if (chrome.runtime.lastError || !res) {
            setShopeeStatus(false)
            resolve(false)
            return
          }
          setShopeeStatus(res.logged)
          if (res.logged) scrapeTab = tabs[0].id
          resolve(res.logged)
        })
      })
    } catch(_) {
      setShopeeStatus(false)
      return false
    }
  }

  // ─── Busca estado do scraping em andamento ────────────────────────────
  async function pollScrapeState() {
    if (!scrapeTab) return

    try {
      chrome.tabs.sendMessage(scrapeTab, { type: 'GET_SCRAPE_STATE' }, state => {
        if (chrome.runtime.lastError || !state) return
        if (state.running) {
          const pct = state.total > 0 ? Math.round((state.imported / state.total) * 90) + 5 : 5
          setProgress(state.total, state.imported, state.page, pct)
          setRunning(true)
          setStatus(`Pág ${state.page} — ${state.imported.toLocaleString()} importados`, 'blue')
        } else if (isRunning) {
          // Terminou
          setRunning(false)
          setProgress(state.total, state.imported, state.page - 1, 100)
          log(`✅ Concluído! ${state.imported} importados de ${state.total}`, 'ok')
          setStatus(`Concluído: ${state.imported} links importados`, 'green')
          scrapeTab = null
        }
      })
    } catch(_) {}
  }

  // ─── Iniciar scraping ─────────────────────────────────────────────────
  async function startScrape() {
    const storeId  = parseInt(inputStoreId.value.trim())
    const maxLinks = parseInt(inputMaxLinks.value.trim()) || 1000000

    if (!storeId) {
      setStatus('⚠️ Configure o Store ID primeiro', 'yellow')
      return
    }

    // Salva config antes de iniciar
    await new Promise(resolve => {
      chrome.storage.local.set({ kainow_store_id: storeId, kainow_max_links: maxLinks }, resolve)
    })

    setRunning(true)
    setStatus('Iniciando...', 'blue')
    progressSect.classList.add('active')
    setProgress(0, 0, 1, 2)
    log(`Iniciando coleta: Store #${storeId}, max ${maxLinks.toLocaleString()} links`, 'info')

    try {
      // Verifica se já existe aba do Shopee
      const existingTabs = await chrome.tabs.query({ url: 'https://affiliate.shopee.com.br/*' })

      let tabId
      if (existingTabs.length > 0) {
        tabId = existingTabs[0].id
        // Navega para a página de ofertas caso esteja em outra
        if (!existingTabs[0].url.includes('/offer/product_offer')) {
          await chrome.tabs.update(tabId, { url: SHOPEE_OFFERS_URL })
          await waitTabLoad(tabId)
        }
        scrapeTab = tabId
      } else {
        // Abre nova aba
        const tab = await chrome.tabs.create({ url: SHOPEE_OFFERS_URL, active: false })
        tabId = tab.id
        scrapeTab = tabId
        await waitTabLoad(tabId)
      }

      // Injeta e inicia scraping via content script
      chrome.tabs.sendMessage(tabId, {
        type: 'START_SCRAPE_CONTENT',
        storeId,
        maxLinks
      }, res => {
        if (chrome.runtime.lastError) {
          // Content script pode não estar pronto ainda — tenta via executeScript
          log('Injetando script diretamente...', 'info')
          chrome.scripting.executeScript({
            target: { tabId },
            func: injectAndRun,
            args: [storeId, maxLinks]
          }).catch(e => {
            log('❌ Erro ao injetar: ' + e.message, 'err')
            setRunning(false)
          })
        }
      })

      setStatus('Coletando — veja na aba da Shopee', 'blue')
      log('Scraping iniciado na aba #' + tabId, 'ok')

      // Ativa polling de estado
      startPolling()

    } catch (e) {
      log('❌ Erro: ' + e.message, 'err')
      setStatus('Erro ao iniciar', 'red')
      setRunning(false)
    }
  }

  // Função injetada diretamente caso o content script falhe
  function injectAndRun(storeId, maxLinks) {
    // Dispara evento customizado que o content script pode pegar,
    // ou executa o scraping diretamente via autoScrapeShopee
    window.dispatchEvent(new CustomEvent('kainow:start', {
      detail: { storeId, maxLinks }
    }))
  }

  // ─── Aguarda aba carregar ─────────────────────────────────────────────
  function waitTabLoad(tabId) {
    return new Promise(resolve => {
      function listener(id, info) {
        if (id === tabId && info.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(listener)
          setTimeout(resolve, 800) // aguarda JS carregar
        }
      }
      chrome.tabs.onUpdated.addListener(listener)
      // Timeout de segurança
      setTimeout(() => {
        chrome.tabs.onUpdated.removeListener(listener)
        resolve()
      }, 15000)
    })
  }

  // ─── Polling de progresso ─────────────────────────────────────────────
  let pollTimer = null
  function startPolling() {
    clearInterval(pollTimer)
    pollTimer = setInterval(pollScrapeState, 1500)
  }
  function stopPolling() {
    clearInterval(pollTimer)
    pollTimer = null
  }

  // ─── Parar scraping ───────────────────────────────────────────────────
  async function stopScrape() {
    stopPolling()

    if (scrapeTab) {
      try {
        // Injeta código para interromper o scraping
        await chrome.scripting.executeScript({
          target: { tabId: scrapeTab },
          func: () => {
            window.__kainowStop = true
            const el = document.getElementById('kainow-content-overlay')
            if (el) {
              const s = document.getElementById('kr-status')
              if (s) s.textContent = '⛔ Parado pelo usuário'
            }
          }
        })
      } catch(_) {}
    }

    setRunning(false)
    log('⛔ Scraping parado pelo usuário', 'err')
    scrapeTab = null
  }

  // ─── Abrir Shopee ─────────────────────────────────────────────────────
  function openShopee() {
    chrome.tabs.create({ url: SHOPEE_OFFERS_URL, active: true })
  }

  // ─── Ir para aba de scraping ──────────────────────────────────────────
  async function gotoScrapeTab() {
    if (scrapeTab) {
      try {
        await chrome.tabs.update(scrapeTab, { active: true })
        const tab = await chrome.tabs.get(scrapeTab)
        await chrome.windows.update(tab.windowId, { focused: true })
      } catch(_) {
        openShopee()
      }
    } else {
      openShopee()
    }
  }

  // ─── Ouve mensagens do background / content ───────────────────────────
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'SCRAPE_DONE') {
      stopPolling()
      setRunning(false)
      setProgress(msg.total || 0, msg.imported || 0, msg.pages || 1, 100)
      log(`🎉 Concluído! ${(msg.imported || 0).toLocaleString()} links importados`, 'ok')
      setStatus(`Concluído: ${(msg.imported || 0).toLocaleString()} links`, 'green')
      scrapeTab = null
    }

    if (msg.type === 'SCRAPE_PROGRESS') {
      const pct = msg.total > 0 ? Math.round((msg.imported / msg.total) * 90) + 5 : 5
      setProgress(msg.total || 0, msg.imported || 0, msg.page || 1, pct)
      if (msg.status) setStatus(msg.status, 'blue')
    }
  })

  // ─── Eventos dos botões ───────────────────────────────────────────────
  btnSave.addEventListener('click', saveConfig)
  btnStart.addEventListener('click', startScrape)
  btnStop.addEventListener('click', stopScrape)
  btnGoto.addEventListener('click', gotoScrapeTab)
  btnOpenShopee.addEventListener('click', openShopee)

  // Enter no campo salva
  inputStoreId.addEventListener('keydown', e => { if (e.key === 'Enter') saveConfig() })

  // ─── Init ────────────────────────────────────────────────────────────
  async function init() {
    setStatus('Carregando...', 'yellow')
    loadConfig()

    // Verifica se há scraping em andamento (aba já aberta)
    const tabs = await chrome.tabs.query({ url: 'https://affiliate.shopee.com.br/*' }).catch(() => [])

    if (tabs.length > 0) {
      scrapeTab = tabs[0].id
      await checkShopeeLogin()
      // Verifica se já está rodando
      chrome.tabs.sendMessage(tabs[0].id, { type: 'GET_SCRAPE_STATE' }, state => {
        if (state?.running) {
          setRunning(true)
          setStatus('Scraping em andamento...', 'blue')
          progressSect.classList.add('active')
          startPolling()
        } else {
          setStatus('Pronto para coletar', 'green')
        }
      })
    } else {
      setShopeeStatus(false)
      setStatus('Shopee não aberta — clique "Abrir"', 'yellow')
    }

    validateForm()
  }

  init()

})()
