// popup.js — KainowRadar Shopee Extension v1.3
;(function () {
  'use strict'

  const SHOPEE_URL   = 'https://affiliate.shopee.com.br/offer/product_offer'
  const SHOPEE_API   = 'https://affiliate.shopee.com.br/api/v1/offer/product_offer?page_number=1&page_size=1'
  const KAINOW_ADMIN = 'https://kainowradar.com.br/admin'

  // ─── Elementos ───────────────────────────────────────────────────────
  const $ = id => document.getElementById(id)

  const screens = {
    login:   $('screen-login'),
    config:  $('screen-config'),
    running: $('screen-running'),
    done:    $('screen-done'),
  }

  const btnOpenShopee  = $('btn-open-shopee')
  const btnCheckLogin  = $('btn-check-login')
  const inputStoreId   = $('input-store-id')
  const inputMaxLinks  = $('input-max-links')
  const btnStart       = $('btn-start')
  const btnLogout      = $('btn-logout-screen')
  const runSub         = $('run-sub')
  const statFound      = $('stat-found')
  const statImported   = $('stat-imported')
  const statPages      = $('stat-pages')
  const runBar         = $('run-bar')
  const runMsg         = $('run-msg')
  const runLog         = $('run-log')
  const btnGotoTab     = $('btn-goto-tab')
  const btnStop        = $('btn-stop')
  const doneTitle      = $('done-title')
  const doneSub        = $('done-sub')
  const btnOpenAdmin   = $('btn-open-admin')
  const btnAgain       = $('btn-collect-again')
  const footerStatus   = $('footer-status')

  // ─── Estado ──────────────────────────────────────────────────────────
  let scrapeTabId = null
  let pollTimer   = null
  let lastStats   = { total: 0, imported: 0, page: 1 }

  // ─── Navegação ────────────────────────────────────────────────────────
  function showScreen(name) {
    Object.values(screens).forEach(s => s.classList.remove('active'))
    screens[name].classList.add('active')
  }

  // ─── Log ─────────────────────────────────────────────────────────────
  function addLog(msg, cls = '') {
    const line = document.createElement('div')
    line.className = 'log-line ' + cls
    const t = new Date().toLocaleTimeString('pt-BR', { hour:'2-digit', minute:'2-digit', second:'2-digit' })
    line.textContent = `${t} ${msg}`
    runLog.appendChild(line)
    runLog.scrollTop = runLog.scrollHeight
    while (runLog.children.length > 60) runLog.removeChild(runLog.firstChild)
  }

  // ─── Verificar login ─────────────────────────────────────────────────
  // Método 1: injeta script na aba da Shopee para fazer fetch com credenciais
  async function checkLoginViaTab() {
    try {
      // Procura aba da Shopee já aberta
      const tabs = await chrome.tabs.query({ url: 'https://affiliate.shopee.com.br/*' })
      if (!tabs.length) return false

      // Injeta um fetch na aba — ela tem os cookies, o popup não tem
      const results = await chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: async () => {
          try {
            const r = await fetch(
              'https://affiliate.shopee.com.br/api/v1/offer/product_offer?page_number=1&page_size=1',
              { credentials: 'include', headers: { 'x-requested-with': 'XMLHttpRequest' } }
            )
            return { status: r.status, ok: r.ok }
          } catch(e) {
            return { status: 0, ok: false, error: e.message }
          }
        }
      })
      const res = results?.[0]?.result
      return res?.ok === true && res?.status === 200
    } catch(e) {
      return false
    }
  }

  // Método 2: verifica cookies com url completa
  async function checkLoginViaCookies() {
    const urls = [
      'https://affiliate.shopee.com.br',
      'https://shopee.com.br',
    ]
    const names = ['SPC_ST', 'SPC_U', 'SPC_F', 'SPC_SI', 'SPC_EC']

    for (const url of urls) {
      for (const name of names) {
        const cookie = await chrome.cookies.get({ url, name }).catch(() => null)
        if (cookie && cookie.value && cookie.value.length > 5) return true
      }
    }
    return false
  }

  // Método 3: pinga content script
  async function checkLoginViaContentScript() {
    try {
      const tabs = await chrome.tabs.query({ url: 'https://affiliate.shopee.com.br/*' })
      if (!tabs.length) return null
      return new Promise(resolve => {
        chrome.tabs.sendMessage(tabs[0].id, { type: 'PING' }, res => {
          if (chrome.runtime.lastError || !res) resolve(null)
          else { scrapeTabId = tabs[0].id; resolve(res.logged) }
        })
      })
    } catch(_) { return null }
  }

  // Tenta todos os métodos em sequência
  async function checkLogin() {
    // 1. Cookies diretos (mais rápido)
    if (await checkLoginViaCookies()) return true
    // 2. Fetch injetado na aba (mais confiável — prova que a sessão funciona)
    if (await checkLoginViaTab()) return true
    // 3. Content script
    const cs = await checkLoginViaContentScript()
    if (cs === true) return true
    return false
  }

  // ─── Salvar / Carregar config ─────────────────────────────────────────
  function loadConfig() {
    chrome.storage.local.get(['kainow_store_id', 'kainow_max_links'], data => {
      if (data.kainow_store_id) inputStoreId.value = data.kainow_store_id
      if (data.kainow_max_links) inputMaxLinks.value = data.kainow_max_links
      validateStart()
    })
  }

  function validateStart() {
    const v = parseInt(inputStoreId.value)
    btnStart.disabled = !v || v < 1
  }

  inputStoreId.addEventListener('input', validateStart)

  // ─── Botão: Abrir Shopee ──────────────────────────────────────────────
  btnOpenShopee.addEventListener('click', async () => {
    // Abre aba da Shopee
    const tab = await chrome.tabs.create({ url: SHOPEE_URL, active: true })
    footerStatus.textContent = 'Aguardando login...'

    // Polling: verifica a cada 2s se já logou
    let attempts = 0
    const timer = setInterval(async () => {
      attempts++
      // Injeta fetch de verificação na aba aberta
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: async () => {
            try {
              const r = await fetch(
                'https://affiliate.shopee.com.br/api/v1/offer/product_offer?page_number=1&page_size=1',
                { credentials: 'include', headers: { 'x-requested-with': 'XMLHttpRequest' } }
              )
              return r.ok
            } catch(_) { return false }
          }
        })
        if (results?.[0]?.result === true) {
          clearInterval(timer)
          scrapeTabId = tab.id
          onLoggedIn()
        }
      } catch(_) {}
      if (attempts > 60) clearInterval(timer) // desiste após 2 min
    }, 2000)
  })

  // ─── Botão: Verificar agora ───────────────────────────────────────────
  btnCheckLogin.addEventListener('click', async () => {
    const spin  = $('check-spin')
    const label = $('check-label')
    const hint  = $('login-hint')

    // Mostra loading
    spin.style.display  = 'inline-block'
    label.textContent   = 'Verificando...'
    btnCheckLogin.disabled = true
    hint.style.display  = 'none'

    let logged = false
    try { logged = await checkLogin() } catch(_) {}

    // Restaura
    spin.style.display  = 'none'
    btnCheckLogin.disabled = false
    label.textContent   = '✅ Já fiz login — continuar'

    if (logged) {
      onLoggedIn()
    } else {
      hint.innerHTML = `
        <strong>⚠️ Sessão não detectada.</strong><br>
        • Clique <strong>"Abrir Shopee Afiliados"</strong> acima<br>
        • Faça login na aba que abrir<br>
        • <em>Deixe a aba aberta</em> e clique este botão novamente
      `
      hint.style.display = 'block'
    }
  })

  function onLoggedIn() {
    chrome.storage.local.set({ shopee_logged: true })
    loadConfig()
    showScreen('config')
    footerStatus.textContent = '✅ Logado na Shopee'
  }

  // ─── Tela Config ──────────────────────────────────────────────────────
  btnStart.addEventListener('click', async () => {
    const storeId  = parseInt(inputStoreId.value)
    const maxLinks = parseInt(inputMaxLinks.value) || 0
    if (!storeId || storeId < 1) { inputStoreId.focus(); return }
    await new Promise(r => chrome.storage.local.set({ kainow_store_id: storeId, kainow_max_links: maxLinks }, r))
    startScrape(storeId, maxLinks)
  })

  btnLogout.addEventListener('click', async () => {
    await new Promise(r => chrome.storage.local.set({ shopee_logged: false }, r))
    showScreen('login')
    footerStatus.textContent = 'Extensão v1.3'
  })

  // ─── Iniciar scraping ─────────────────────────────────────────────────
  async function startScrape(storeId, maxLinks) {
    showScreen('running')
    resetStats()
    addLog('Iniciando coleta...', 'log-inf')
    runSub.textContent = 'Preparando...'

    try {
      // Garante que tem aba da Shopee aberta
      const existing = await chrome.tabs.query({ url: 'https://affiliate.shopee.com.br/*' })
      if (existing.length > 0) {
        scrapeTabId = existing[0].id
        if (!existing[0].url.includes('/offer/product_offer')) {
          await chrome.tabs.update(scrapeTabId, { url: SHOPEE_URL })
          await waitTabLoad(scrapeTabId)
        }
        addLog('Usando aba existente', 'log-inf')
      } else {
        const tab = await chrome.tabs.create({ url: SHOPEE_URL, active: false })
        scrapeTabId = tab.id
        await waitTabLoad(scrapeTabId)
        addLog('Nova aba aberta', 'log-inf')
      }

      // Envia comando para content script
      chrome.tabs.sendMessage(scrapeTabId, {
        type: 'START_SCRAPE_CONTENT',
        storeId,
        maxLinks: maxLinks || 1000000
      }, res => {
        if (chrome.runtime.lastError) {
          // Content script não carregou — injeta manualmente
          chrome.scripting.executeScript({
            target: { tabId: scrapeTabId },
            files: ['content.js']
          }).then(() => {
            setTimeout(() => {
              chrome.tabs.sendMessage(scrapeTabId, {
                type: 'START_SCRAPE_CONTENT',
                storeId,
                maxLinks: maxLinks || 1000000
              })
            }, 800)
          }).catch(e => showError('Erro ao injetar script: ' + e.message))
        }
      })

      runSub.textContent = 'Coletando em background...'
      startPolling()
      addLog('Scraping iniciado!', 'log-ok')

    } catch(e) {
      showError(e.message)
      addLog('Erro: ' + e.message, 'log-err')
    }
  }

  function waitTabLoad(tabId) {
    return new Promise(resolve => {
      const fn = (id, info) => {
        if (id === tabId && info.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(fn)
          setTimeout(resolve, 1200)
        }
      }
      chrome.tabs.onUpdated.addListener(fn)
      setTimeout(() => { chrome.tabs.onUpdated.removeListener(fn); resolve() }, 20000)
    })
  }

  // ─── Polling de progresso ─────────────────────────────────────────────
  function startPolling() {
    clearInterval(pollTimer)
    pollTimer = setInterval(async () => {
      if (!scrapeTabId) { clearInterval(pollTimer); return }
      try { await chrome.tabs.get(scrapeTabId) }
      catch(_) { clearInterval(pollTimer); scrapeTabId = null; return }

      chrome.tabs.sendMessage(scrapeTabId, { type: 'GET_SCRAPE_STATE' }, state => {
        if (chrome.runtime.lastError || !state) return
        updateRunUI(state)
        if (!state.running && (state.total > 0 || state.imported > 0)) {
          clearInterval(pollTimer)
          showDone(state.total, state.imported, (state.page || 1) - 1)
        }
      })
    }, 1500)
  }

  function updateRunUI(s) {
    lastStats = s
    statFound.textContent    = (s.total    || 0).toLocaleString('pt-BR')
    statImported.textContent = (s.imported || 0).toLocaleString('pt-BR')
    statPages.textContent    = s.page || 1
    const pct = s.total > 0 ? Math.min(95, Math.round((s.imported / s.total) * 90) + 5) : 5
    runBar.style.width = pct + '%'
    if (s.total > 0) runSub.textContent = `Pág ${s.page} • ${(s.imported || 0).toLocaleString('pt-BR')} importados`
  }

  function resetStats() {
    statFound.textContent = statImported.textContent = statPages.textContent = '0'
    runBar.style.width = '0%'
    runMsg.textContent = ''
    runLog.innerHTML = ''
    lastStats = { total: 0, imported: 0, page: 1 }
  }

  // ─── Parar ────────────────────────────────────────────────────────────
  btnStop.addEventListener('click', async () => {
    clearInterval(pollTimer)
    if (scrapeTabId) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: scrapeTabId },
          func: () => { window.__kainowStop = true }
        })
      } catch(_) {}
    }
    addLog('⏹ Parado', 'log-err')
    showDone(lastStats.total, lastStats.imported, lastStats.page)
  })

  btnGotoTab.addEventListener('click', async () => {
    if (scrapeTabId) {
      try {
        await chrome.tabs.update(scrapeTabId, { active: true })
        const t = await chrome.tabs.get(scrapeTabId)
        chrome.windows.update(t.windowId, { focused: true })
      } catch(_) { chrome.tabs.create({ url: SHOPEE_URL }) }
    } else {
      chrome.tabs.create({ url: SHOPEE_URL })
    }
  })

  // ─── Done ─────────────────────────────────────────────────────────────
  function showDone(total, imported, pages) {
    scrapeTabId = null
    doneTitle.textContent = `${(imported || 0).toLocaleString('pt-BR')} links importados!`
    doneSub.textContent   = `${(total || 0).toLocaleString('pt-BR')} encontrados em ${pages || 1} páginas`
    showScreen('done')
    footerStatus.textContent = `✅ ${(imported || 0).toLocaleString('pt-BR')} importados`
  }

  function showError(msg) {
    doneTitle.textContent = '❌ Erro'
    doneTitle.style.color = '#f87171'
    doneSub.textContent = msg
    showScreen('done')
  }

  btnOpenAdmin.addEventListener('click', () => chrome.tabs.create({ url: KAINOW_ADMIN }))
  btnAgain.addEventListener('click', () => {
    doneTitle.style.color = ''
    showScreen('config')
  })

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'SCRAPE_DONE') {
      clearInterval(pollTimer)
      showDone(msg.total, msg.imported, msg.pages)
    }
  })

  // ─── Init ─────────────────────────────────────────────────────────────
  async function init() {
    footerStatus.textContent = 'Verificando...'

    // Verifica se tem flag salva E sessão ainda ativa
    const stored = await new Promise(r =>
      chrome.storage.local.get(['shopee_logged', 'kainow_store_id'], r)
    )

    if (stored.shopee_logged) {
      // Confirma rapidamente se a sessão ainda existe
      const still = await checkLogin().catch(() => false)
      if (still) {
        loadConfig()
        showScreen('config')
        footerStatus.textContent = '✅ Logado'
        return
      }
      // Sessão expirou — limpa flag
      chrome.storage.local.set({ shopee_logged: false })
    }

    // Checa silenciosamente sem nenhuma flag salva
    const logged = await checkLogin().catch(() => false)
    if (logged) {
      onLoggedIn()
    } else {
      showScreen('login')
      footerStatus.textContent = 'Aguardando login'
    }
  }

  init()
})()
