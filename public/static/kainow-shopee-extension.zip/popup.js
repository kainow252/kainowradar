// popup.js — KainowRadar Shopee Extension v1.1
;(function () {
  'use strict'

  const SHOPEE_URL   = 'https://affiliate.shopee.com.br/offer/product_offer'
  const KAINOW_ADMIN = 'https://kainowradar.com.br/admin'

  // ─── Elementos ───────────────────────────────────────────────────────
  const $ = id => document.getElementById(id)

  // Telas
  const screens = {
    login:   $('screen-login'),
    config:  $('screen-config'),
    running: $('screen-running'),
    done:    $('screen-done'),
  }

  // Tela de login
  const btnOpenShopee  = $('btn-open-shopee')
  const btnCheckLogin  = $('btn-check-login')
  const checkSpin      = $('check-spin')

  // Tela de config
  const inputStoreId   = $('input-store-id')
  const inputMaxLinks  = $('input-max-links')
  const btnStart       = $('btn-start')
  const btnLogout      = $('btn-logout-screen')

  // Tela rodando
  const runSub         = $('run-sub')
  const statFound      = $('stat-found')
  const statImported   = $('stat-imported')
  const statPages      = $('stat-pages')
  const runBar         = $('run-bar')
  const runMsg         = $('run-msg')
  const runLog         = $('run-log')
  const btnGotoTab     = $('btn-goto-tab')
  const btnStop        = $('btn-stop')

  // Tela done
  const doneTitle      = $('done-title')
  const doneSub        = $('done-sub')
  const btnOpenAdmin   = $('btn-open-admin')
  const btnAgain       = $('btn-collect-again')

  // Footer
  const footerStatus   = $('footer-status')

  // ─── Estado ─────────────────────────────────────────────────────────
  let scrapeTabId = null
  let pollTimer   = null
  let isLoggedIn  = false
  let lastStats   = { total: 0, imported: 0, page: 1 }

  // ─── Navegação entre telas ───────────────────────────────────────────
  function showScreen(name) {
    Object.values(screens).forEach(s => s.classList.remove('active'))
    screens[name].classList.add('active')
  }

  // ─── Log ─────────────────────────────────────────────────────────────
  function addLog(msg, cls = '') {
    const line = document.createElement('div')
    line.className = 'log-line ' + cls
    const t = new Date().toLocaleTimeString('pt-BR', { hour:'2-digit', minute:'2-digit', second:'2-digit' })
    line.textContent = `${t} ${msg}`
    runLog.appendChild(line)
    runLog.scrollTop = runLog.scrollHeight
    while (runLog.children.length > 60) runLog.removeChild(runLog.firstChild)
  }

  // ─── Verificar login via cookies ─────────────────────────────────────
  // Usa chrome.cookies para ver se tem sessão ativa na Shopee
  async function checkShopeeLoginViaCookies() {
    return new Promise(resolve => {
      // Verifica os cookies de sessão da Shopee Afiliados
      chrome.cookies.getAll({ domain: 'shopee.com.br' }, cookies => {
        if (chrome.runtime.lastError) { resolve(false); return }
        // Cookies que indicam sessão logada
        const sessionCookies = ['SPC_ST', 'SPC_U', 'SPC_F', 'SPC_EC', 'SPC_CDS']
        const found = cookies.some(c => sessionCookies.includes(c.name) && c.value && c.value.length > 5)
        resolve(found)
      })
    })
  }

  // Fallback: tenta pingar content script em aba aberta
  async function checkLoginViaContentScript() {
    try {
      const tabs = await chrome.tabs.query({ url: 'https://affiliate.shopee.com.br/*' })
      if (!tabs.length) return null // aba não está aberta

      return new Promise(resolve => {
        chrome.tabs.sendMessage(tabs[0].id, { type: 'PING' }, res => {
          if (chrome.runtime.lastError || !res) resolve(null)
          else { scrapeTabId = tabs[0].id; resolve(res.logged) }
        })
      })
    } catch (_) { return null }
  }

  async function checkLogin() {
    // 1. Tenta via cookies (mais confiável, não precisa de aba aberta)
    const byCookie = await checkShopeeLoginViaCookies()
    if (byCookie) return true

    // 2. Fallback: tenta content script
    const byCS = await checkLoginViaContentScript()
    if (byCS === true) return true

    return false
  }

  // ─── Salvar / carregar config ────────────────────────────────────────
  function loadConfig() {
    chrome.storage.local.get(['kainow_store_id', 'kainow_max_links'], data => {
      if (data.kainow_store_id) inputStoreId.value = data.kainow_store_id
      if (data.kainow_max_links) inputMaxLinks.value = data.kainow_max_links
      validateStart()
    })
  }

  function validateStart() {
    const v = parseInt(inputStoreId.value)
    btnStart.disabled = !v || v < 1
  }

  inputStoreId.addEventListener('input', validateStart)

  // ─── Ações: Tela Login ───────────────────────────────────────────────
  btnOpenShopee.addEventListener('click', () => {
    chrome.tabs.create({ url: SHOPEE_URL, active: true })
    // Após abrir, começa a checar periodicamente
    footerStatus.textContent = 'Aguardando login...'
    let attempts = 0
    const timer = setInterval(async () => {
      attempts++
      const logged = await checkLogin()
      if (logged) {
        clearInterval(timer)
        onLoggedIn()
      }
      if (attempts > 30) clearInterval(timer) // desiste após 30 tentativas (~1 min)
    }, 2000)
  })

  btnCheckLogin.addEventListener('click', async () => {
    checkSpin.style.display = 'block'
    btnCheckLogin.disabled = true
    btnCheckLogin.childNodes[1].textContent = ' Verificando...'

    const logged = await checkLogin()

    checkSpin.style.display = 'none'
    btnCheckLogin.disabled = false
    btnCheckLogin.childNodes[1].textContent = ' Já fiz login — verificar agora'

    if (logged) {
      onLoggedIn()
    } else {
      // Anima o botão de abrir para chamar atenção
      btnOpenShopee.style.animation = 'none'
      btnOpenShopee.textContent = '⚠️ Não detectado — abra a Shopee e faça login'
      setTimeout(() => {
        btnOpenShopee.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="white"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9" stroke="white" stroke-width="2" fill="none" stroke-linecap="round"/><line x1="10" y1="14" x2="21" y2="3" stroke="white" stroke-width="2" stroke-linecap="round"/></svg> Abrir Shopee Afiliados`
      }, 3000)
    }
  })

  function onLoggedIn() {
    isLoggedIn = true
    chrome.storage.local.set({ shopee_logged: true })
    loadConfig()
    showScreen('config')
    footerStatus.textContent = '✅ Logado na Shopee'
  }

  // ─── Ações: Tela Config ──────────────────────────────────────────────
  btnStart.addEventListener('click', async () => {
    const storeId  = parseInt(inputStoreId.value)
    const maxLinks = parseInt(inputMaxLinks.value) || 0 // 0 = sem limite

    if (!storeId || storeId < 1) {
      inputStoreId.focus()
      return
    }

    // Salva config
    await new Promise(r => chrome.storage.local.set({ kainow_store_id: storeId, kainow_max_links: maxLinks }, r))

    startScrape(storeId, maxLinks)
  })

  btnLogout.addEventListener('click', async () => {
    await new Promise(r => chrome.storage.local.set({ shopee_logged: false }, r))
    isLoggedIn = false
    showScreen('login')
    footerStatus.textContent = 'Extensão v1.1'
  })

  // ─── Iniciar scraping ────────────────────────────────────────────────
  async function startScrape(storeId, maxLinks) {
    showScreen('running')
    resetStats()
    addLog('Iniciando coleta...', 'log-inf')
    runSub.textContent = 'Abrindo Shopee...'
    runMsg.textContent = 'Aguarde...'

    try {
      // Verifica se já tem aba da Shopee aberta
      const existing = await chrome.tabs.query({ url: 'https://affiliate.shopee.com.br/*' })

      if (existing.length > 0) {
        scrapeTabId = existing[0].id
        // Garante que está na página certa
        if (!existing[0].url.includes('/offer/product_offer')) {
          await chrome.tabs.update(scrapeTabId, { url: SHOPEE_URL })
          await waitForTabLoad(scrapeTabId)
        }
        addLog('Usando aba existente da Shopee', 'log-inf')
      } else {
        // Abre nova aba (em background)
        const tab = await chrome.tabs.create({ url: SHOPEE_URL, active: false })
        scrapeTabId = tab.id
        await waitForTabLoad(scrapeTabId)
        addLog('Nova aba aberta em background', 'log-inf')
      }

      // Envia comando para o content script iniciar
      chrome.tabs.sendMessage(scrapeTabId, {
        type: 'START_SCRAPE_CONTENT',
        storeId,
        maxLinks: maxLinks || 1000000
      }, res => {
        if (chrome.runtime.lastError) {
          // Content script não carregou ainda — injeta via executeScript
          addLog('Injetando script...', 'log-inf')
          chrome.scripting.executeScript({
            target: { tabId: scrapeTabId },
            files: ['content.js']
          }).then(() => {
            setTimeout(() => {
              chrome.tabs.sendMessage(scrapeTabId, {
                type: 'START_SCRAPE_CONTENT',
                storeId,
                maxLinks: maxLinks || 1000000
              })
            }, 500)
          }).catch(e => {
            addLog('Erro ao injetar: ' + e.message, 'log-err')
            showError('Não foi possível iniciar. Verifique se está logado na Shopee.')
          })
        } else {
          addLog('Scraping iniciado!', 'log-ok')
        }
      })

      runSub.textContent = 'Coletando em background...'
      startPolling()

    } catch (e) {
      addLog('Erro: ' + e.message, 'log-err')
      showError(e.message)
    }
  }

  // ─── Aguarda aba carregar ─────────────────────────────────────────────
  function waitForTabLoad(tabId) {
    return new Promise(resolve => {
      const check = (id, info) => {
        if (id === tabId && info.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(check)
          setTimeout(resolve, 1000)
        }
      }
      chrome.tabs.onUpdated.addListener(check)
      setTimeout(() => { chrome.tabs.onUpdated.removeListener(check); resolve() }, 20000)
    })
  }

  // ─── Polling de progresso ─────────────────────────────────────────────
  function startPolling() {
    clearInterval(pollTimer)
    pollTimer = setInterval(async () => {
      if (!scrapeTabId) { clearInterval(pollTimer); return }

      // Verifica se a aba ainda existe
      try { await chrome.tabs.get(scrapeTabId) }
      catch (_) { clearInterval(pollTimer); scrapeTabId = null; return }

      chrome.tabs.sendMessage(scrapeTabId, { type: 'GET_SCRAPE_STATE' }, state => {
        if (chrome.runtime.lastError || !state) return
        updateRunningUI(state)
        if (!state.running && (state.total > 0 || state.imported > 0)) {
          clearInterval(pollTimer)
          showDone(state.total, state.imported, state.page - 1)
        }
      })
    }, 1500)
  }

  function updateRunningUI(state) {
    lastStats = state
    statFound.textContent    = (state.total    || 0).toLocaleString('pt-BR')
    statImported.textContent = (state.imported || 0).toLocaleString('pt-BR')
    statPages.textContent    = state.page || 1

    const pct = state.total > 0 ? Math.min(95, Math.round((state.imported / state.total) * 90) + 5) : 5
    runBar.style.width = pct + '%'

    if (state.total > 0) {
      runSub.textContent = `Pág ${state.page} • ${(state.imported || 0).toLocaleString('pt-BR')} importados`
    }

    // Adiciona log se mudou
    if (state.lastMsg && state.lastMsg !== updateRunningUI._lastMsg) {
      updateRunningUI._lastMsg = state.lastMsg
      addLog(state.lastMsg, state.lastMsgType || '')
    }
  }
  updateRunningUI._lastMsg = ''

  // ─── Resetar stats ────────────────────────────────────────────────────
  function resetStats() {
    statFound.textContent = statImported.textContent = statPages.textContent = '0'
    runBar.style.width = '0%'
    runMsg.textContent = ''
    runLog.innerHTML = ''
    lastStats = { total: 0, imported: 0, page: 1 }
  }

  // ─── Parar scraping ───────────────────────────────────────────────────
  btnStop.addEventListener('click', async () => {
    clearInterval(pollTimer)
    if (scrapeTabId) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: scrapeTabId },
          func: () => { window.__kainowStop = true }
        })
      } catch(_) {}
    }
    addLog('⏹ Parado pelo usuário', 'log-err')
    showDone(lastStats.total, lastStats.imported, lastStats.page)
  })

  // ─── Ir para aba de scraping ──────────────────────────────────────────
  btnGotoTab.addEventListener('click', async () => {
    if (scrapeTabId) {
      try {
        await chrome.tabs.update(scrapeTabId, { active: true })
        const tab = await chrome.tabs.get(scrapeTabId)
        chrome.windows.update(tab.windowId, { focused: true })
      } catch(_) { chrome.tabs.create({ url: SHOPEE_URL }) }
    } else {
      chrome.tabs.create({ url: SHOPEE_URL })
    }
  })

  // ─── Tela Concluído ───────────────────────────────────────────────────
  function showDone(total, imported, pages) {
    scrapeTabId = null
    doneTitle.textContent = `${(imported || 0).toLocaleString('pt-BR')} links importados!`
    doneSub.textContent   = `${(total || 0).toLocaleString('pt-BR')} encontrados em ${pages || 1} páginas`
    showScreen('done')
    footerStatus.textContent = `✅ ${(imported || 0).toLocaleString('pt-BR')} importados`
  }

  function showError(msg) {
    doneTitle.textContent = '❌ Erro na coleta'
    doneTitle.style.color = '#f87171'
    doneSub.textContent   = msg
    showScreen('done')
  }

  btnOpenAdmin.addEventListener('click', () => chrome.tabs.create({ url: KAINOW_ADMIN }))
  btnAgain.addEventListener('click', () => {
    doneTitle.style.color = ''
    showScreen('config')
  })

  // ─── Ouve mensagens do content script / background ────────────────────
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'SCRAPE_DONE') {
      clearInterval(pollTimer)
      showDone(msg.total, msg.imported, msg.pages)
    }
    if (msg.type === 'SCRAPE_PROGRESS') {
      if (screens.running.classList.contains('active')) {
        updateRunningUI({ total: msg.total, imported: msg.imported, page: msg.page, running: true })
        if (msg.status) runMsg.textContent = msg.status
      }
    }
  })

  // ─── Init ────────────────────────────────────────────────────────────
  async function init() {
    footerStatus.textContent = 'Verificando...'

    // Verifica se já estava logado (memória local)
    const stored = await new Promise(r => chrome.storage.local.get(['shopee_logged', 'kainow_store_id'], r))

    if (stored.shopee_logged) {
      // Confirma que o cookie ainda existe
      const stillLogged = await checkLogin()
      if (stillLogged) {
        isLoggedIn = true
        loadConfig()
        showScreen('config')
        footerStatus.textContent = '✅ Logado na Shopee'
        return
      }
    }

    // Faz uma verificação silenciosa mesmo sem flag salva
    const logged = await checkLogin()
    if (logged) {
      onLoggedIn()
    } else {
      showScreen('login')
      footerStatus.textContent = 'Aguardando login'
    }
  }

  init()
})()
