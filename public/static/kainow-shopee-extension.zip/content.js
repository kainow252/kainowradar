// content.js — Script de conteúdo da extensão KainowRadar Shopee
// Roda em: https://affiliate.shopee.com.br/*

;(function () {
  'use strict'

  // Evita dupla injeção
  if (window.__kainowInjected) return
  window.__kainowInjected = true

  const KAINOW_URL = 'https://kainowradar.com.br'

  // ─── Overlay de progresso ────────────────────────────────────────────
  let overlay = null
  let scrapeState = { running: false, total: 0, imported: 0, page: 1 }

  function getOverlay() {
    if (overlay && document.contains(overlay)) return overlay
    overlay = document.createElement('div')
    overlay.id = 'kainow-content-overlay'
    overlay.style.cssText = `
      position:fixed;bottom:24px;right:24px;z-index:2147483647;
      background:#1e293b;color:#f1f5f9;
      padding:16px 20px;border-radius:16px;
      font-family:system-ui,-apple-system,sans-serif;font-size:13px;
      min-width:300px;max-width:360px;
      box-shadow:0 8px 40px rgba(0,0,0,.5);
      border:1px solid #334155;
      transition:opacity .3s;
    `
    overlay.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
        <div style="display:flex;align-items:center;gap:8px">
          <div style="width:10px;height:10px;border-radius:50%;background:#EE4D2D;box-shadow:0 0 6px #EE4D2D60"></div>
          <strong style="color:#EE4D2D;font-size:14px">KainowRadar</strong>
          <span style="color:#475569;font-size:11px">Shopee Sync</span>
        </div>
        <button id="kr-close" style="background:none;border:none;color:#64748b;cursor:pointer;font-size:16px;line-height:1;padding:0">✕</button>
      </div>
      <div id="kr-status" style="color:#94a3b8;margin-bottom:10px;font-size:12px;min-height:16px">Pronto</div>
      <div style="background:#0f172a;border-radius:8px;height:5px;overflow:hidden;margin-bottom:10px">
        <div id="kr-bar" style="height:100%;background:linear-gradient(90deg,#EE4D2D,#FF7337);width:0%;transition:width .4s ease"></div>
      </div>
      <div style="display:flex;gap:16px;font-size:11px;color:#64748b">
        <span>📦 <strong id="kr-found" style="color:#f1f5f9">0</strong></span>
        <span>✅ <strong id="kr-saved" style="color:#22c55e">0</strong> importados</span>
        <span>📄 Pág <strong id="kr-page" style="color:#93c5fd">1</strong></span>
      </div>
    `
    document.body.appendChild(overlay)
    document.getElementById('kr-close').addEventListener('click', () => {
      overlay.style.opacity = '0'
      setTimeout(() => overlay?.remove(), 300)
    })
    return overlay
  }

  function setStatus(msg)  { const e = document.getElementById('kr-status'); if(e) e.textContent = msg }
  function setBar(pct)     { const e = document.getElementById('kr-bar');    if(e) e.style.width = Math.min(100, pct) + '%' }
  function setStat(f,i,p)  {
    const ef = document.getElementById('kr-found')
    const ei = document.getElementById('kr-saved')
    const ep = document.getElementById('kr-page')
    if(ef) ef.textContent = f
    if(ei) ei.textContent = i
    if(ep) ep.textContent = p
  }

  // ─── API interna da Shopee ────────────────────────────────────────────
  async function fetchProductPage(page, pageSize = 100) {
    const url = new URL('https://affiliate.shopee.com.br/api/v1/offer/product_offer')
    url.searchParams.set('page_number', page)
    url.searchParams.set('page_size', pageSize)
    url.searchParams.set('need_products_info', '1')
    url.searchParams.set('sort_type', '2')

    const res = await fetch(url.toString(), {
      credentials: 'include',
      headers: {
        'Accept': 'application/json',
        'x-requested-with': 'XMLHttpRequest'
      }
    })

    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    const json = await res.json()
    // Tenta diferentes paths de resposta
    const data = json?.data
    const offers = data?.offers || data?.list || (Array.isArray(data) ? data : [])
    const totalCount = data?.total_count || data?.total || 0
    return { offers, total: totalCount }
  }

  async function generateLink(itemId, shopId) {
    try {
      const res = await fetch('https://affiliate.shopee.com.br/api/v1/offer/generate_affiliate_link', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({ item_id: itemId, shop_id: shopId || 0 })
      })
      if (!res.ok) return null
      const d = await res.json()
      return d?.data?.short_link || d?.data?.affiliate_link || null
    } catch(_) { return null }
  }

  // "Obter Link em Massa" via API interna (endpoint de bulk)
  async function fetchBulkLinks(items) {
    try {
      // Tenta endpoint de bulk
      const res = await fetch('https://affiliate.shopee.com.br/api/v1/offer/batch_generate_affiliate_link', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({ items })
      })
      if (!res.ok) return []
      const d = await res.json()
      const links = d?.data?.links || d?.data || []
      return Array.isArray(links) ? links.map(l => l.short_link || l.affiliate_link).filter(Boolean) : []
    } catch(_) { return [] }
  }

  // ─── Enviar links para KainowRadar ────────────────────────────────────
  async function sendLinksToKainow(links, storeId) {
    // Usa o background para buscar config
    return new Promise(resolve => {
      chrome.runtime.sendMessage(
        { type: 'SHOPEE_LINKS', links, storeId },
        res => resolve(res || { ok: false })
      )
    })
  }

  // ─── Scraping principal ───────────────────────────────────────────────
  async function runScrape(storeId, maxLinks) {
    if (scrapeState.running) {
      setStatus('⚠️ Scraping já em andamento...')
      return
    }

    scrapeState = { running: true, total: 0, imported: 0, page: 1 }
    getOverlay() // garante que o overlay está visível

    setStatus('Iniciando coleta de produtos...')
    setBar(2)

    const PAGE_SIZE = 100

    try {
      let hasMore = true

      while (hasMore && scrapeState.total < maxLinks) {
        setStatus(`Buscando página ${scrapeState.page}...`)
        setBar(5 + Math.min(scrapeState.page * 2, 40))

        let offers = []
        let totalServerCount = 0

        try {
          const result = await fetchProductPage(scrapeState.page, PAGE_SIZE)
          offers = result.offers
          totalServerCount = result.total
        } catch (err) {
          setStatus(`❌ Erro ao buscar: ${err.message}`)
          if (err.message.includes('401') || err.message.includes('403')) {
            setStatus('🔐 Sessão expirada — faça login na Shopee')
          }
          break
        }

        if (!offers.length) {
          hasMore = false
          break
        }

        // Extrai links diretos
        const directLinks = []
        const needsGen = []

        for (const o of offers) {
          const link = o.short_link || o.affiliate_link || o.offer_link
          if (link && (link.includes('shope') || link.includes('s.') || link.startsWith('http'))) {
            directLinks.push(link)
          } else {
            const itemId = o.item_id || o.product_id
            const shopId = o.shop_id
            if (itemId) needsGen.push({ itemId, shopId })
          }
        }

        let links = [...directLinks]

        // Tenta bulk generation para os que não têm link direto
        if (needsGen.length > 0) {
          setStatus(`Gerando ${needsGen.length} links (bulk)...`)
          const bulkItems = needsGen.map(x => ({ item_id: x.itemId, shop_id: x.shopId }))
          const bulkLinks = await fetchBulkLinks(bulkItems)

          if (bulkLinks.length > 0) {
            links = links.concat(bulkLinks)
          } else {
            // Fallback: gera um por um (mais lento)
            setStatus(`Gerando links individualmente (${needsGen.length})...`)
            let genCount = 0
            for (const item of needsGen) {
              const gl = await generateLink(item.itemId, item.shopId)
              if (gl) links.push(gl)
              genCount++
              if (genCount % 10 === 0) {
                setStatus(`Gerando... ${genCount}/${needsGen.length}`)
                setStat(scrapeState.total + links.length, scrapeState.imported, scrapeState.page)
              }
              await new Promise(r => setTimeout(r, 50)) // anti-rate-limit
            }
          }
        }

        scrapeState.total += links.length
        setStat(scrapeState.total, scrapeState.imported, scrapeState.page)

        if (links.length > 0) {
          setStatus(`Pág ${scrapeState.page}: ${links.length} links → enviando...`)

          // Envia em chunks de 50
          const CHUNK = 50
          for (let i = 0; i < links.length; i += CHUNK) {
            const chunk = links.slice(i, i + CHUNK)
            const res = await sendLinksToKainow(chunk, storeId)
            scrapeState.imported += (res.imported || chunk.length)
            setStat(scrapeState.total, scrapeState.imported, scrapeState.page)
            setBar(50 + Math.round((scrapeState.imported / Math.max(scrapeState.total, 1)) * 45))
          }
        }

        // Verifica se há mais páginas
        if (offers.length < PAGE_SIZE) {
          hasMore = false
        } else if (totalServerCount > 0 && scrapeState.total >= totalServerCount) {
          hasMore = false
        }

        scrapeState.page++
        await new Promise(r => setTimeout(r, 600)) // respira entre páginas
      }

      setBar(100)
      setStatus(`🎉 Concluído! ${scrapeState.imported} links importados de ${scrapeState.total} encontrados`)

      // Notifica o popup
      try {
        chrome.runtime.sendMessage({
          type: 'SCRAPE_DONE',
          total: scrapeState.total,
          imported: scrapeState.imported,
          pages: scrapeState.page - 1
        })
      } catch(_) {}

    } catch (e) {
      setStatus(`❌ Erro: ${e.message}`)
    } finally {
      scrapeState.running = false
    }
  }

  // ─── Recebe mensagens do popup e background ───────────────────────────
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === 'PING') {
      sendResponse({ ok: true, url: location.href, logged: isLoggedIn() })
      return true
    }

    if (msg.type === 'START_SCRAPE_CONTENT') {
      runScrape(msg.storeId, msg.maxLinks || 100000)
        .then(() => sendResponse({ ok: true }))
        .catch(e => sendResponse({ ok: false, error: e.message }))
      return true
    }

    if (msg.type === 'SHOW_OVERLAY') {
      getOverlay()
      sendResponse({ ok: true })
      return true
    }

    if (msg.type === 'GET_SCRAPE_STATE') {
      sendResponse({ ...scrapeState })
      return true
    }
  })

  // ─── Detecta se está logado ───────────────────────────────────────────
  function isLoggedIn() {
    // Verifica presença de cookies de sessão ou elementos da UI autenticada
    return document.cookie.includes('SPC_ST') ||
           document.cookie.includes('SPC_U') ||
           !!document.querySelector('.affiliate-header-user, .user-info, [class*="username"], [class*="UserName"]')
  }

  // ─── Inicia automaticamente se veio de um comando ────────────────────
  // O background pode ter injetado um atributo no body para auto-iniciar
  const autoStart = document.body?.dataset?.kainowAutoStart
  if (autoStart) {
    const [storeId, maxLinks] = autoStart.split(':')
    setTimeout(() => runScrape(storeId, parseInt(maxLinks) || 100000), 1000)
  }

  // Informa ao background que o content script está pronto
  try {
    chrome.runtime.sendMessage({ type: 'CONTENT_READY', url: location.href, logged: isLoggedIn() })
  } catch(_) {}

})()
