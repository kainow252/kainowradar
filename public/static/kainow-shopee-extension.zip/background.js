// background.js — Service Worker da extensão KainowRadar Shopee

const KAINOW_URL = 'https://kainowradar.com.br'

// Recebe mensagens do content script
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'SHOPEE_LINKS') {
    handleLinks(msg.links, msg.storeId, msg.token).then(sendResponse)
    return true // async
  }
  if (msg.type === 'GET_CONFIG') {
    chrome.storage.local.get(['kainow_token','kainow_store_id','kainow_url'], data => {
      sendResponse(data)
    })
    return true
  }
  if (msg.type === 'SAVE_CONFIG') {
    chrome.storage.local.set({
      kainow_token:    msg.token,
      kainow_store_id: msg.storeId,
      kainow_url:      msg.url || KAINOW_URL
    }, () => sendResponse({ ok: true }))
    return true
  }
  if (msg.type === 'START_SCRAPE') {
    startScrape(msg.storeId, msg.limit).then(sendResponse)
    return true
  }
})

// Envia links para o KainowRadar
async function handleLinks(links, storeId, token) {
  if (!links || !links.length) return { ok: false, error: 'Sem links' }
  const cfg = await getConfig()
  const baseUrl = cfg.kainow_url || KAINOW_URL
  const sid = storeId || cfg.kainow_store_id
  if (!sid) return { ok: false, error: 'Store ID não configurado' }

  try {
    const res = await fetch(`${baseUrl}/admin/api/stores/${sid}/import-links`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ links: links.join('\n') })
    })
    const data = await res.json()
    return { ok: true, imported: data.imported || data.saved || links.length, total: links.length }
  } catch(e) {
    return { ok: false, error: e.message }
  }
}

// Busca config do storage
function getConfig() {
  return new Promise(resolve => {
    chrome.storage.local.get(['kainow_token','kainow_store_id','kainow_url'], resolve)
  })
}

// Inicia scraping automático nas abas da Shopee
async function startScrape(storeId, limit) {
  const cfg = await getConfig()
  const sid = storeId || cfg.kainow_store_id
  if (!sid) return { ok: false, error: 'Configure o Store ID primeiro!' }

  // Abre a página de ofertas
  const tab = await chrome.tabs.create({
    url: 'https://affiliate.shopee.com.br/offer/product_offer',
    active: true
  })

  // Aguarda carregar e injeta o script de scraping
  return new Promise(resolve => {
    chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener)
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: autoScrapeShopee,
          args: [sid, limit || 1000]
        }).then(results => {
          resolve(results?.[0]?.result || { ok: true })
        }).catch(e => resolve({ ok: false, error: e.message }))
      }
    })
  })
}

// Função injetada na página da Shopee para fazer scraping
function autoScrapeShopee(storeId, maxLinks) {
  // Esta função roda DENTRO da página da Shopee
  // Tem acesso total ao DOM e às APIs internas
  return new Promise(async (resolve) => {
    const KAINOW = 'https://kainowradar.com.br'
    const PAGE_SIZE = 100
    let page = 1
    let total = 0
    let imported = 0
    let hasMore = true

    // Mostra overlay de progresso na página
    const overlay = document.createElement('div')
    overlay.id = 'kainow-overlay'
    overlay.style.cssText = `
      position:fixed;top:20px;right:20px;z-index:999999;
      background:#1e293b;color:#f1f5f9;
      padding:16px 20px;border-radius:16px;
      font-family:system-ui,sans-serif;font-size:13px;
      min-width:280px;box-shadow:0 8px 32px rgba(0,0,0,0.4);
      border:1px solid #334155;
    `
    overlay.innerHTML = `
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
        <img src="https://kainowradar.com.br/static/logos/shopee.svg" style="width:24px;height:24px" onerror="this.style.display='none'">
        <strong style="color:#EE4D2D;font-size:14px">KainowRadar</strong>
        <span style="color:#64748b;font-size:11px">Shopee Afiliados</span>
      </div>
      <div id="kr-status" style="color:#94a3b8;margin-bottom:8px">Iniciando...</div>
      <div style="background:#0f172a;border-radius:8px;height:6px;overflow:hidden;margin-bottom:8px">
        <div id="kr-bar" style="height:100%;background:linear-gradient(90deg,#EE4D2D,#FF7337);width:0%;transition:width 0.4s"></div>
      </div>
      <div style="display:flex;gap:12px;font-size:11px;color:#64748b">
        <span>📦 <strong id="kr-found" style="color:#f1f5f9">0</strong> encontrados</span>
        <span>✅ <strong id="kr-imported" style="color:#22c55e">0</strong> importados</span>
        <span>📄 Pág <strong id="kr-page" style="color:#f1f5f9">1</strong></span>
      </div>
    `
    document.body.appendChild(overlay)

    function setStatus(msg) { const el = document.getElementById('kr-status'); if(el) el.textContent = msg }
    function setBar(pct)    { const el = document.getElementById('kr-bar');    if(el) el.style.width = pct + '%' }
    function setStat(f,i,p) {
      const ef=document.getElementById('kr-found'), ei=document.getElementById('kr-imported'), ep=document.getElementById('kr-page')
      if(ef) ef.textContent=f; if(ei) ei.textContent=i; if(ep) ep.textContent=p
    }

    try {
      while (hasMore && total < maxLinks) {
        setStatus(`Buscando página ${page}...`)
        setBar(Math.min(5 + page * 3, 50))

        // Chama a API interna da Shopee (browser já tem os cookies!)
        const r = await fetch(
          `https://affiliate.shopee.com.br/api/v1/offer/product_offer?page_number=${page}&page_size=${PAGE_SIZE}&need_products_info=1&sort_type=2`,
          { credentials: 'include', headers: { 'Accept': 'application/json', 'x-requested-with': 'XMLHttpRequest' } }
        )

        if (!r.ok) {
          setStatus(`❌ Erro ${r.status} — verifique o login`)
          break
        }

        const json = await r.json()
        const offers = json?.data?.offers || json?.data?.list || json?.data || []
        if (!Array.isArray(offers) || !offers.length) { hasMore = false; break }

        // Extrai links de afiliado
        const links = []
        for (const o of offers) {
          // Tenta pegar o link curto (s.shopee.com.br) ou gerar via API
          const link = o.short_link || o.affiliate_link || o.offer_link
          if (link) {
            links.push(link)
          } else if (o.item_id || o.product_id) {
            // Gera link de afiliado pela API
            try {
              const lr = await fetch('https://affiliate.shopee.com.br/api/v1/offer/generate_affiliate_link', {
                method: 'POST',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                body: JSON.stringify({ item_id: o.item_id || o.product_id, shop_id: o.shop_id || 0 })
              })
              if (lr.ok) {
                const ld = await lr.json()
                const gl = ld?.data?.short_link || ld?.data?.affiliate_link
                if (gl) links.push(gl)
              }
            } catch(_) {}
          }
        }

        if (!links.length && offers.length > 0) {
          // Fallback: usa "Obter Link em Massa" — clica checkbox de todos
          setStatus('Usando "Obter Link em Massa"...')
          try {
            // Seleciona todos na página
            const selectAll = document.querySelector('input[type="checkbox"].select-all, .ant-checkbox-input, input[aria-label="Select all"]')
            if (selectAll) {
              selectAll.click()
              await new Promise(r => setTimeout(r, 500))
              // Clica botão "Obter Link em Massa"
              const massBtn = Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('Obter Link em Massa') || b.textContent.includes('Get Link in Bulk'))
              if (massBtn) {
                massBtn.click()
                await new Promise(r => setTimeout(r, 1500))
                // Pega links do modal/área que aparece
                const linkEls = document.querySelectorAll('.generated-link, .affiliate-link, [class*="link"] input, textarea')
                for (const el of linkEls) {
                  const v = el.value || el.textContent
                  if (v && v.includes('shopee')) links.push(v.trim())
                }
              }
            }
          } catch(_) {}
        }

        total += links.length
        setStat(total, imported, page)
        setStatus(`Página ${page}: ${links.length} links — enviando para KainowRadar...`)

        // Envia para o KainowRadar em chunks de 50
        const CHUNK = 50
        for (let i = 0; i < links.length; i += CHUNK) {
          const chunk = links.slice(i, i + CHUNK)
          setBar(50 + Math.round((imported / Math.max(total, 1)) * 45))
          try {
            const sr = await fetch(`${KAINOW}/admin/api/stores/${storeId}/import-links`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ links: chunk.join('\n') })
            })
            const sd = await sr.json()
            imported += (sd.imported || sd.saved || 0)
            setStat(total, imported, page)
          } catch(_) {}
        }

        if (offers.length < PAGE_SIZE) { hasMore = false; break }
        page++
        await new Promise(r => setTimeout(r, 700))
      }
    } catch(e) {
      setStatus('❌ ' + e.message)
    }

    setBar(100)
    setStatus(`🎉 Concluído! ${imported} produtos importados`)

    // Remove overlay após 5s
    setTimeout(() => overlay?.remove(), 5000)
    resolve({ ok: true, total, imported, pages: page })
  })
}
